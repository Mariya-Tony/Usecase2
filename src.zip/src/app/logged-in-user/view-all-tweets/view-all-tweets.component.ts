import { Component, Input, OnInit } from '@angular/core';
import { LoginService } from 'src/app/service/login.service';
import { TweetMessageService } from 'src/app/service/tweet-message.service';

@Component({
  selector: 'app-view-all-tweets',
  templateUrl: './view-all-tweets.component.html',
  styleUrls: ['./view-all-tweets.component.css']
})
export class ViewAllTweetsComponent implements OnInit {

  allTweetData: any = [];
  tweetData: any[] = [];
  allTweetUsers: any[] = [];
  constructor(
    private tweetMessageService: TweetMessageService,
    private loginService: LoginService
  ) { }

  ngOnInit(): void {
    this.getAllUserDetails();
    this.getAllTweets();
  }

  public async getAllTweets() {
    setTimeout(() => {
      this.tweetMessageService.viewAllTweets().subscribe(
        data => {
          if (Object.keys(data).length > 0) {
            this.allTweetData = data.reverse();
            this.allTweetData.forEach((element: any = {}) => {
              this.allTweetUsers.forEach(index => {
                if (element.userId === index.userId) {
                  element.firstName = index.firstName;
                  element.userName = element.firstName + element.userId.slice(-4);
                  element.postTime = element.createdAt;
                }
              });
            });
            this.allTweetData;
          }
        });
    }, 100);
  }

  async getAllUserDetails() {
    this.loginService.getAllUsers().subscribe(
      data => {
        if (Object.keys(data).length > 0) {
          this.allTweetUsers = data;
        }
      });
  }

}
